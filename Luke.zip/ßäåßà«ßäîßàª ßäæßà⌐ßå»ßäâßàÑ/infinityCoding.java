/**
 * 
 */
/**
 * @author lukeseonkwonkim
 * @serial Hello World!
 */

public class infinityCoding {
	
	public static void main(String args[]){
		
		System.out.println("Hello World!");
		}
	
}