import java.util.Scanner;
/**
 * 
 */
/**
 * @author lukeseonkwonkim
 * @serial A + B - 6
 */ 

public class infinityCoding7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scan = new Scanner(System.in);
		 
	        int n = scan.nextInt();
	        
	        for(int i = 0; i < n; i++){
	            String[] number = scan.next().split(",");
	            System.out.println(Integer.parseInt(number[0])+Integer.parseInt(number[1]));   
	        }
	        scan.close();
	}
}
