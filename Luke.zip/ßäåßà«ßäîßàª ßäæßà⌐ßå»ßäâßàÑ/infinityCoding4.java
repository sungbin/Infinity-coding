import java.util.*;
/**
 * 
 */
/**
 * @author lukeseonkwonkim
 * @serial A + B - 3
 */ 

public class infinityCoding4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		int i;
        i = scan.nextInt();
        
        while ((i--) > 0) {
            int a, b;    
            
            a = scan.nextInt();
            b = scan.nextInt();
            
            System.out.println(a + b);
        }
        scan.close();
	}

}
