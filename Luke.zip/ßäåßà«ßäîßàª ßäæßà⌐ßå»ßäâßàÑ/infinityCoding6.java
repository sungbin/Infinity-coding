import java.util.*;
/**
 * 
 */
/**
 * @author lukeseonkwonkim
 * @serial A + B - 5
 */ 

public class infinityCoding6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
        int a, b;
        while (scan.hasNextInt()) {
        	
            a = scan.nextInt();
            b = scan.nextInt();
            
            if((a==0)&&(b==0))
                break;
            
            System.out.println(a + b);
            
        }
        scan.close();
	}
}
