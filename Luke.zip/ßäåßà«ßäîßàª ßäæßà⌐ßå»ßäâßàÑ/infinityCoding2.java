import java.util.*;
/**
 * 
 */
/**
 * @author lukeseonkwonkim
 * @serial A + B
 */

public class infinityCoding2 {
    public static void main(String args[]){
        
        Scanner scan = new Scanner(System.in);
        
        int a, b;
        a = scan.nextInt();
        b = scan.nextInt();
        
        System.out.println(a + b);
        
        scan.close();
        
    }
}
