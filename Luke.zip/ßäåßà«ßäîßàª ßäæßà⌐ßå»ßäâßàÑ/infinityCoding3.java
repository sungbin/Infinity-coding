import java.util.*;
/**
 * 
 */
/**
 * @author lukeseonkwonkim
 * @serial A +  B - 2
 */ 

public class infinityCoding3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Scanner scan = new Scanner(System.in);
	        
	        int a, b;
	        a = scan.nextInt();
	        b = scan.nextInt();
	        scan.close();
	        
	        System.out.println(a + b);
	}

}
