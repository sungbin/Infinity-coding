import java.util.*;
/**
 * 
 */
/**
 * @author lukeseonkwonkim
 * @serial A + B - 4
 */ 

public class infinityCoding5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	       Scanner scan = new Scanner(System.in);
	       
	        int a, b;
	        while (scan.hasNextInt()) {
	            a = scan.nextInt();
	            b = scan.nextInt();
	            
	            System.out.println(a + b);
	        }
	        scan.close();
	}
}
