import java.util.*;
/**
 * 
 */
/**
 * @author lukeseonkwonkim
 * @serial A + B - 7
 */ 

public class infinityCoding8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		int i, x;
		x = 0;
        i = scan.nextInt();
        
        while ((i--) > 0) {
            int a, b;    
            
            a = scan.nextInt();
            b = scan.nextInt();
            x++;
            System.out.println("Case #" + x + ":" + (a + b));
        }
        scan.close();
	}

}
